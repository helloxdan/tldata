package com.thinkgem.jeesite.modules.tl.service;

public class RegPhone {
	public RegPhone(String phone, int i) {
		this.phone = phone;
		this.index = i;
	}

	String phone;
	int index;
}
